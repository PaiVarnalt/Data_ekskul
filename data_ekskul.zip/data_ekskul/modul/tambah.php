<?php
include "../lib/koneksi.php";

$notif = "";

if(isset($_POST['simpan'])){
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $ekskul = $_POST['ekskul'];
    $pembina = $_POST['pembina'];

    if($nama == "" || $kelas == "" || $ekskul == "" || $pembina == ""){
        $notif = '<div class="alert alert-danger">Tidak boleh ada field kosong!</div>';
    } else {

        $sql = $conn->prepare("INSERT INTO tb_peserta 
        (nama_lengkap, kelas_siswa, nama_ekskul, pembina, waktu_input)
        VALUES (:nama, :kelas, :ekskul, :pembina, NOW())");

        $sql->bindParam(':nama', $nama);
        $sql->bindParam(':kelas', $kelas);
        $sql->bindParam(':ekskul', $ekskul);
        $sql->bindParam(':pembina', $pembina);

        if($sql->execute()){
            $notif = '<div class="alert alert-success">Data berhasil ditambahkan!</div>';
        } else {
            $notif = '<div class="alert alert-danger">Gagal menambahkan data!</div>';
        }
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Tambah Peserta Ekskul</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container mt-4">

<h3>Tambah Peserta Ekskul</h3>
<?= $notif ?>

<form method="POST">
    <input type="text" name="nama" class="form-control mb-2" placeholder="Nama Lengkap">
    <input type="text" name="kelas" class="form-control mb-2" placeholder="Kelas">
    <input type="text" name="ekskul" class="form-control mb-2" placeholder="Ekskul">
    <input type="text" name="pembina" class="form-control mb-2" placeholder="Pembina">
    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
</form>

</body>
</html>
