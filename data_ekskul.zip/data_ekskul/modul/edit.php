<?php
include "../lib/koneksi.php";

$id = $_GET['id'];

// SELECT pakai bindParam
$ambil = $conn->prepare("SELECT * FROM tb_peserta WHERE id_peserta = :id");
$ambil->bindParam(':id', $id, PDO::PARAM_INT);
$ambil->execute();
$data = $ambil->fetch();

$notif = "";

if(isset($_POST['update'])){
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $ekskul = $_POST['ekskul'];
    $pembina = $_POST['pembina'];

    if($nama == "" || $kelas == "" || $ekskul == "" || $pembina == ""){
        $notif = '<div class="alert alert-danger">Semua field wajib diisi!</div>';
    } else {

        // UPDATE pakai bindParam
        $sql = $conn->prepare("UPDATE tb_peserta 
                               SET nama_lengkap = :nama,
                                   kelas_siswa = :kelas,
                                   nama_ekskul = :ekskul,
                                   pembina = :pembina
                               WHERE id_peserta = :id");

        $sql->bindParam(':nama', $nama);
        $sql->bindParam(':kelas', $kelas);
        $sql->bindParam(':ekskul', $ekskul);
        $sql->bindParam(':pembina', $pembina);
        $sql->bindParam(':id', $id, PDO::PARAM_INT);

        if($sql->execute()){
            $notif = '<div class="alert alert-success">Data berhasil diperbarui!</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Peserta Ekskul</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container mt-4">

<h3>Edit Peserta Ekskul</h3>

<?= $notif ?>

<form method="POST">

    <label>Nama Lengkap</label>
    <input type="text" name="nama" class="form-control mb-2" 
           value="<?= $data['nama_lengkap']; ?>">

    <label>Kelas</label>
    <input type="text" name="kelas" class="form-control mb-2" 
           value="<?= $data['kelas_siswa']; ?>">

    <label>Ekskul</label>
    <input type="text" name="ekskul" class="form-control mb-2" 
           value="<?= $data['nama_ekskul']; ?>">

    <label>Pembina</label>
    <input type="text" name="pembina" class="form-control mb-2" 
           value="<?= $data['pembina']; ?>">

    <button type="submit" name="update" class="btn btn-primary mt-2">
        Update Data
    </button>

    <a href="../index.php" class="btn btn-secondary mt-2">Kembali</a>

</form>

</body>
</html>
