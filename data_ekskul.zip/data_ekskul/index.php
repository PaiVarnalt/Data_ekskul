<?php 
include "lib/koneksi.php";

$keyword = "";
if(isset($_GET['cari'])){
    $keyword = $_GET['keyword'];
    $query = $conn->prepare("SELECT * FROM tb_peserta 
                             WHERE nama_lengkap LIKE ? OR nama_ekskul LIKE ?");
    $query->execute(["%$keyword%", "%$keyword%"]);
} else {
    $query = $conn->prepare("SELECT * FROM tb_peserta ORDER BY id_peserta DESC");
    $query->execute();
}
$data = $query->fetchAll();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Peserta Ekskul</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="container mt-4">
<h3>Data Peserta Ekskul</h3>

<form class="mb-3" method="get">
    <input type="text" name="keyword" class="form-control w-50 d-inline" placeholder="Cari nama/ekskul">
    <button class="btn btn-info" name="cari">Cari</button>
</form>

<a href="modul/tambah.php" class="btn btn-primary mb-3">Tambah Data</a>

<table class="table table-bordered">
    <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Kelas</th>
        <th>Ekskul</th>
        <th>Pembina</th>
        <th>Waktu Input</th>
        <th>Aksi</th>
    </tr>

    <?php foreach($data as $row): ?>
    <tr>
        <td><?= $row['id_peserta'] ?></td>
        <td><?= $row['nama_lengkap'] ?></td>
        <td><?= $row['kelas_siswa'] ?></td>
        <td><?= $row['nama_ekskul'] ?></td>
        <td><?= $row['pembina'] ?></td>
        <td><?= $row['waktu_input'] ?></td>
        <td>
            <a href="modul/edit.php?id=<?= $row['id_peserta'] ?>" class="btn btn-warning btn-sm">Edit</a>
            <a href="modul/hapus.php?id=<?= $row['id_peserta'] ?>" class="btn btn-danger btn-sm"
               onclick="return confirm('Yakin hapus?')">Hapus</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
</body>
</html>
